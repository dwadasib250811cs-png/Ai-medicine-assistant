# 💊 AI Powered Medicine Assistant

An AI-based assistant that identifies medicines from images and speaks their names aloud — designed to help visually impaired individuals.

## 🚀 Features
- Medicine recognition using deep learning
- Text-to-speech output (English, Telugu, Malayalam)
- Light adaptation for clear recognition
- Runs directly in Google Colab

## 🧠 Tech Stack
- TensorFlow / Keras
- OpenCV
- Google Text-to-Speech (gTTS)
- Python

## 🧰 How to Run (Colab)
1. Open in Colab using this link (replace YOUR_USERNAME):

https://colab.research.google.com/github/YOUR_USERNAME/ai-medicine-assistant/blob/main/ai_medicine_assistant.ipynb

2. Upload:
   - medicine_model.h5
   - labels.json
   - a sample medicine image

3. Run all cells — it will identify the medicine and speak the result aloud.

## 🗣️ Multi-language Support
```python
predict_and_speak("medicine_model.h5", "labels.json", "sample.jpg", lang="te")  # Telugu
predict_and_speak("medicine_model.h5", "labels.json", "sample.jpg", lang="ml")  # Malayalam
```

## 🏆 Made for
Synapse 2K25 – NIT Calicut | AI Medicine Identification Challenge
